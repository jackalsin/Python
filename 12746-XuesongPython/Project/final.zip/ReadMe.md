#12746 Project
##Requirement
1. python 2.7 or above
2. pygame

##Run

#Issues
When running program, it will print "libpng warning: iCCP: known incorrect sRGB profile"
This is a knowing issue for pygame.

##Citations:
http://programarcadegames.com/python_examples/f.php?file=pygame_base_template.py
http://nullege.com/codes/show/src%40w%40r%40writing_games_tutorial-HEAD%40examples%40example4%40example1.py/221/pygame.font.Font.render/python
http://stackoverflow.com/questions/2399307/how-to-invoke-the-super-constructor-in-python