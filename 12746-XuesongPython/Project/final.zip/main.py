# main.py
import titleScreen, sys

# I can't find where I originally cited... 
# but this is cited from stackoverflow to solve bootUp crush
# http://stackoverflow.com/questions/419163/what-does-if-name-main-do
if __name__ == "__main__":  
    t = titleScreen.TitleScreen()
