class Book(object):
    def __init__(self, number, title, author, price, pages):
        self.number = number
        self.title = title
        self.author = author
        self.price = price
        self.pages = pages

    